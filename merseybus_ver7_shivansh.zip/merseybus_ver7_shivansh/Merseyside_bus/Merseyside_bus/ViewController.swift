//
//  ViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

import UIKit
import Firebase
import FirebaseAuth
import GoogleSignIn

class ViewController: UIViewController {
    
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var accountLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    
    
    @IBAction func continueButtonTapped(_ sender: Any) {
            guard let email = emailTextField.text, !email.isEmpty else {
                print("Email field is empty")
                return
            }
            
            let db = Firestore.firestore()
            
            // Generate a UID for manually signed-in users
            let uid = UUID().uuidString
            
            let userData: [String: Any] = [
                "email": email,
                "displayName": accountLabel.text ?? "",
                "photoURL": "", // No photo URL for manual signup
                "uid": uid,
                "createdAt": FieldValue.serverTimestamp(),
                "signInMethod": "Manual"
            ]
            
            db.collection("users").document(uid).setData(userData) { error in
                if let error = error {
                    print("Error saving manual user to Firestore: \(error.localizedDescription)")
                } else {
                    print("Manual user saved successfully to Firestore!")
                    self.performSegue(withIdentifier: "toMenu", sender: nil)
                }
            }
        }

    @IBAction func googleSignInButtonTapped(_ sender: Any) {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        guard let presentingVC = UIApplication.shared.windows.first?.rootViewController else {
            print("Error: Unable to get root view controller")
            return
        }
        
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingVC) { result, error in
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }
            
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                print("Missing user or ID token")
                return
            }
            
            let accessToken = user.accessToken.tokenString
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
            
            Auth.auth().signIn(with: credential) { authResult, error in
                if let error = error {
                    print("Firebase Sign-In failed: \(error.localizedDescription)")
                    return
                }
                
                print("Firebase Sign-In Success! User: \(authResult?.user.email ?? "No Email")")
                
                if let user = authResult?.user {
                    self.saveUserToFirestore(user: user)
                }
                
                self.performSegue(withIdentifier: "toMenu", sender: nil)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup if needed
    }
    
    // MARK: - Save user info to Firestore
    func saveUserToFirestore(user: User) {
        let db = Firestore.firestore()
        
        let userData: [String: Any] = [
            "email": user.email ?? "",
            "displayName": user.displayName ?? "",
            "photoURL": user.photoURL?.absoluteString ?? "",
            "uid": user.uid,
            "createdAt": FieldValue.serverTimestamp(),
            "signInMethod": "Google"
        ]
        
        db.collection("users").document(user.uid).setData(userData) { error in
            if let error = error {
                print("Error saving Google user to Firestore: \(error.localizedDescription)")
            } else {
                print("Google user saved successfully to Firestore!")
            }
        }
    }
}

