//
//  MyScheduleViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 28/04/2025.
//

import UIKit
import FirebaseFirestore

class MyScheduleViewController: UIViewController{

    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier: "toMenu", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    
}
