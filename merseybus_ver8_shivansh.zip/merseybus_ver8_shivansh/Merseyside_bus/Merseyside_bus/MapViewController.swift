//
//  MapViewController.swift
//  Merseyside_bus
//
//  Updated Journey Code with Start Button & Fixed Bus Animation
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate {

    @IBOutlet weak var startTF: UITextField!
    @IBOutlet weak var endTF: UITextField!
    @IBOutlet weak var timeTF: UITextField!
    @IBOutlet weak var endPicker: UIPickerView!
    @IBOutlet weak var myMap: MKMapView!
    @IBOutlet weak var startPicker: UIPickerView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var startJourneyButton: UIButton!

    var routes: [(name: String, stops: [BusStop])] = []
    var expandedIndexSet: Set<Int> = []
    var highlightedRouteIndex: Int? = nil
    
    var busAnnotation: MKPointAnnotation? = nil
    var busTimer: Timer?
    var busPathCoordinates: [CLLocationCoordinate2D] = []
    var currentBusIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        startJourneyButton.isHidden = true // Hide until route found
        
        loadBusData()
    }
    
    func loadBusData() {
        if let url = Bundle.main.url(forResource: "BusStopsSuper", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decodedData = try JSONDecoder().decode(SuperBusData.self, from: data)
                
                for (routeName, superRoute) in decodedData.routes {
                    routes.append((name: routeName, stops: superRoute.stops))
                }
                
                self.tableView.reloadData()
            } catch {
                print("Error decoding JSON: \(error)")
            }
        } else {
            print("BusStopsSuper.json file not found")
        }
    }
    
    @IBAction func goButton(_ sender: Any) {
        view.endEditing(true)
        findBestRoute()
    }
    
    func findBestRoute() {
        guard let startText = startTF.text?.lowercased(),
              let endText = endTF.text?.lowercased(),
              !startText.isEmpty,
              !endText.isEmpty else {
            print("Start or End text field is empty.")
            return
        }
        
        highlightedRouteIndex = nil
        
        for (index, route) in routes.enumerated() {
            let stopNames = route.stops.map { $0.stop_name.lowercased() }
            
            if let startIndex = stopNames.firstIndex(where: { $0.contains(startText) }),
               let endIndex = stopNames.firstIndex(where: { $0.contains(endText) }),
               startIndex < endIndex {
                
                if let userTime = timeTF.text, !userTime.isEmpty {
                    let matchingTimes = route.stops[startIndex].times.filter { $0 >= userTime }
                    if matchingTimes.isEmpty {
                        continue
                    }
                }
                
                highlightedRouteIndex = index
                drawRouteOnMap(stops: Array(route.stops[startIndex...endIndex]))
                break
            }
        }
        
        tableView.reloadData()
        if highlightedRouteIndex != nil {
            startJourneyButton.isHidden = false // Show start journey button when route is found
        }
    }
    
    func drawRouteOnMap(stops: [BusStop]) {
        myMap.removeAnnotations(myMap.annotations)
        myMap.removeOverlays(myMap.overlays)
        
        // Add stop annotations
        for stop in stops {
            let coordinate = CLLocationCoordinate2D(latitude: stop.latitude, longitude: stop.longitude)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = stop.stop_name
            myMap.addAnnotation(annotation)
        }
        
        // Request directions between consecutive stops
        if stops.count >= 2 {
            var allCoordinates: [CLLocationCoordinate2D] = []
            var segmentsCompleted = 0
            
            for i in 0..<(stops.count - 1) {
                let sourceCoordinate = CLLocationCoordinate2D(latitude: stops[i].latitude, longitude: stops[i].longitude)
                let destinationCoordinate = CLLocationCoordinate2D(latitude: stops[i+1].latitude, longitude: stops[i+1].longitude)
                
                let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
                let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate)
                
                let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
                let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
                
                let directionRequest = MKDirections.Request()
                directionRequest.source = sourceMapItem
                directionRequest.destination = destinationMapItem
                directionRequest.transportType = .automobile // Use automobile as proxy for bus routes
                
                let directions = MKDirections(request: directionRequest)
                directions.calculate { [weak self] (response, error) in
                    guard let self = self else { return }
                    
                    if let error = error {
                        print("Error calculating directions: \(error.localizedDescription)")
                        // Fallback to straight line if directions fail
                        let polyline = MKPolyline(coordinates: [sourceCoordinate, destinationCoordinate], count: 2)
                        self.myMap.addOverlay(polyline)
                        allCoordinates.append(sourceCoordinate)
                        allCoordinates.append(destinationCoordinate)
                    } else if let response = response, let route = response.routes.first {
                        // Add each route segment to map
                        self.myMap.addOverlay(route.polyline)
                        
                        // Add coordinates to our path collection
                        let routeCoordinates = self.getCoordinatesFromPolyline(route.polyline)
                        allCoordinates.append(contentsOf: routeCoordinates)
                    }
                    
                    segmentsCompleted += 1
                    
                    // If all segments are processed, update the bus path
                    if segmentsCompleted == stops.count - 1 {
                        self.busPathCoordinates = allCoordinates
                        self.currentBusIndex = 0
                    }
                }
            }
        }
        
        // Center map on first stop
        if let first = stops.first {
            let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: first.latitude, longitude: first.longitude), latitudinalMeters: 3000, longitudinalMeters: 3000)
            myMap.setRegion(region, animated: true)
        }
    }
    
    func getCoordinatesFromPolyline(_ polyline: MKPolyline) -> [CLLocationCoordinate2D] {
        var coordinates = [CLLocationCoordinate2D](repeating: CLLocationCoordinate2D(), count: polyline.pointCount)
        polyline.getCoordinates(&coordinates, range: NSRange(location: 0, length: polyline.pointCount))
        return coordinates
    }
    
    @IBAction func zoomOutPressed(_ sender: Any) {
        var region = myMap.region
            region.span.latitudeDelta *= 2
            region.span.longitudeDelta *= 2
            myMap.setRegion(region, animated: true)
    }
    
    @IBAction func zoomInPressed(_ sender: Any) {
        var region = myMap.region
            region.span.latitudeDelta /= 2
            region.span.longitudeDelta /= 2
            myMap.setRegion(region, animated: true)
        
    }
    
    @IBAction func startJourneyPressed(_ sender: Any) {
        startBusSimulation()
    }
    
    func startBusSimulation() {
        busTimer?.invalidate()
        
        // Remove old bus annotation if it exists
        if let busAnnotation = busAnnotation {
            myMap.removeAnnotation(busAnnotation)
        }
        
        // Create new bus annotation
        let newBusAnnotation = MKPointAnnotation()
        if let firstCoordinate = busPathCoordinates.first {
            newBusAnnotation.coordinate = firstCoordinate
            newBusAnnotation.title = "Bus"
        }
        busAnnotation = newBusAnnotation
        myMap.addAnnotation(newBusAnnotation)
        
        currentBusIndex = 0
        // Start the timer a bit slower for more realistic movement
        busTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(moveBus), userInfo: nil, repeats: true)
    }
    
    @objc func moveBus() {
        guard currentBusIndex < busPathCoordinates.count else {
            busTimer?.invalidate()
            return
        }
        
        let nextCoord = busPathCoordinates[currentBusIndex]
        
        // Update bus annotation position
        UIView.animate(withDuration: 0.9) {
            self.busAnnotation?.coordinate = nextCoord
        }
        
        currentBusIndex += 1
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = UIColor.systemBlue
            renderer.lineWidth = 4
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // Don't customize user location
        if annotation is MKUserLocation {
            return nil
        }
        
        // Check if it's our bus annotation
        if annotation === busAnnotation {
            let identifier = "busAnnotation"
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            
            if annotationView == nil {
                annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                annotationView?.canShowCallout = true
            } else {
                annotationView?.annotation = annotation
            }
            
            // Set bus image
            annotationView?.image = UIImage(named: "busIcon") ?? UIImage(systemName: "bus")
            
            return annotationView
        }
        
        // For bus stops
        let identifier = "stopMarker"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
        } else {
            annotationView?.annotation = annotation
        }
        
        // Create a small dot for bus stops
        let dotSize: CGFloat = 8.0
        let dotView = UIView(frame: CGRect(x: 0, y: 0, width: dotSize, height: dotSize))
        dotView.backgroundColor = UIColor.red
        dotView.layer.cornerRadius = dotSize / 2
        
        // Create a custom image from the dot view
        UIGraphicsBeginImageContextWithOptions(dotView.bounds.size, false, 0)
        if let context = UIGraphicsGetCurrentContext() {
            dotView.layer.render(in: context)
            let dotImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            annotationView?.image = dotImage
        }
        
        return annotationView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return routes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let route = routes[indexPath.row]
        
        let attributedText = NSMutableAttributedString()
        let isExpanded = expandedIndexSet.contains(indexPath.row)
        let expandIcon = isExpanded ? "➖" : "➕"
        
        let routeTitleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 18)
        ]
        let title = NSAttributedString(string: "\(expandIcon) \(route.name)\n", attributes: routeTitleAttributes)
        attributedText.append(title)
        
        if isExpanded {
            let stopAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 16)
            ]
            for stop in route.stops {
                let stopLine = NSAttributedString(string: "   • \(stop.stop_name)\n", attributes: stopAttributes)
                attributedText.append(stopLine)
            }
        }
        
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.attributedText = attributedText
        cell.backgroundColor = (highlightedRouteIndex == indexPath.row) ? UIColor.systemBlue.withAlphaComponent(0.3) : UIColor.clear
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if expandedIndexSet.contains(indexPath.row) {
            expandedIndexSet.remove(indexPath.row)
        } else {
            expandedIndexSet.insert(indexPath.row)
        }
        
        tableView.reloadRows(at: [indexPath], with: .automatic)
    }
}
