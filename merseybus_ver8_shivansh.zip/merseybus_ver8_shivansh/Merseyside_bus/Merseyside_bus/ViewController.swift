//
//  ViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import GoogleSignIn

class ViewController: UIViewController {
    
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var accountLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup if needed
    }
    
    @IBAction func continueButtonTapped(_ sender: Any) {
        guard let email = emailTextField.text, !email.isEmpty else {
            print("Email field is empty")
            return
        }
        
        let db = Firestore.firestore()
        
        // Generate a UID for manually signed-in users
        let uid = UUID().uuidString
        
        let userData: [String: Any] = [
            "email": email,
            "displayName": accountLabel.text ?? "",
            "photoURL": "", // No photo URL for manual signup
            "uid": uid,
            "createdAt": FieldValue.serverTimestamp(),
            "signInMethod": "Manual"
        ]
        
        db.collection("users").document(uid).setData(userData) { error in
            if let error = error {
                print("Error saving manual user to Firestore: \(error.localizedDescription)")
            } else {
                print("Manual user saved successfully to Firestore!")
                self.performSegue(withIdentifier: "toMenu", sender: nil)
            }
        }
    }
    
    @IBAction func googleSignInButtonTapped(_ sender: Any) {
        // Disable the button to prevent multiple taps
        if let button = sender as? UIButton {
            button.isEnabled = false
        }
        
        // Show loading indicator
        let loadingIndicator = UIActivityIndicatorView(style: .medium)
        loadingIndicator.center = self.view.center
        loadingIndicator.tag = 999
        loadingIndicator.startAnimating()
        self.view.addSubview(loadingIndicator)
        
        // Clear any existing sign-in state
        GIDSignIn.sharedInstance.signOut()
        
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            handleSignInCompletion(success: false, error: "Configuration error")
            return
        }
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        // Add retry mechanism
        attemptGoogleSignIn(retryCount: 3)
    }
    
    func attemptGoogleSignIn(retryCount: Int) {
        guard retryCount > 0 else {
            handleSignInCompletion(success: false, error: "Maximum retries exceeded")
            return
        }
        
        guard let presentingVC = self.getTopViewController() else {
            handleSignInCompletion(success: false, error: "Unable to present sign-in")
            return
        }
        
        // Set up a timeout
        var timeoutWorkItem: DispatchWorkItem?
        timeoutWorkItem = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            // If this executes, it means the sign-in timed out
            if retryCount > 1 {
                print("Sign-in attempt timed out, retrying... (\(retryCount-1) attempts left)")
                self.attemptGoogleSignIn(retryCount: retryCount - 1)
            } else {
                self.handleSignInCompletion(success: false, error: "Connection timed out")
            }
        }
        
        // Schedule the timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: timeoutWorkItem!)
        
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingVC) { [weak self] result, error in
            guard let self = self else { return }
            
            // Cancel the timeout since we got a response
            timeoutWorkItem?.cancel()
            
            if let error = error {
                print("Google Sign-In error: \(error.localizedDescription)")
                
                // Check for network errors that might benefit from retry
                if self.isNetworkRelatedError(error) && retryCount > 1 {
                    print("Network-related error, retrying... (\(retryCount-1) attempts left)")
                    // Add a small delay before retry
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        self.attemptGoogleSignIn(retryCount: retryCount - 1)
                    }
                    return
                }
                
                self.handleSignInCompletion(success: false, error: "Authentication failed")
                return
            }
            
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                self.handleSignInCompletion(success: false, error: "Missing user data")
                return
            }
            
            let accessToken = user.accessToken.tokenString
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
            
            // Use a shorter timeout for Firebase auth
            var firebaseTimeoutWorkItem: DispatchWorkItem?
            firebaseTimeoutWorkItem = DispatchWorkItem { [weak self] in
                guard let self = self else { return }
                self.handleSignInCompletion(success: false, error: "Firebase authentication timed out")
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 8.0, execute: firebaseTimeoutWorkItem!)
            
            Auth.auth().signIn(with: credential) { [weak self] authResult, error in
                guard let self = self else { return }
                
                // Cancel the timeout
                firebaseTimeoutWorkItem?.cancel()
                
                if let error = error {
                    print("Firebase auth error: \(error.localizedDescription)")
                    self.handleSignInCompletion(success: false, error: "Firebase authentication failed")
                    return
                }
                
                if let user = authResult?.user {
                    self.saveUserToFirestore(user: user) { success in
                        if success {
                            self.handleSignInCompletion(success: true)
                        } else {
                            // Continue anyway, as Firestore save isn't critical for auth
                            self.handleSignInCompletion(success: true)
                        }
                    }
                } else {
                    self.handleSignInCompletion(success: true)
                }
            }
        }
    }
    
    // Updated to include completion handler
    func saveUserToFirestore(user: User, completion: @escaping (Bool) -> Void) {
        let db = Firestore.firestore()
        
        let userData: [String: Any] = [
            "email": user.email ?? "",
            "displayName": user.displayName ?? "",
            "photoURL": user.photoURL?.absoluteString ?? "",
            "uid": user.uid,
            "createdAt": FieldValue.serverTimestamp(),
            "signInMethod": "Google",
            "lastSignIn": FieldValue.serverTimestamp()
        ]
        
        db.collection("users").document(user.uid).setData(userData, merge: true) { error in
            if let error = error {
                print("Error saving Google user to Firestore: \(error.localizedDescription)")
                completion(false)
            } else {
                print("Google user saved successfully to Firestore!")
                completion(true)
            }
        }
    }
    
    func handleSignInCompletion(success: Bool, error: String? = nil) {
        // Clean up UI
        hideLoadingIndicator()
        
        // Re-enable the button - Fixed syntax
        for case let button as UIButton in self.view.subviews {
            button.isEnabled = true
        }
        
        if success {
            // Proceed to next screen
            self.performSegue(withIdentifier: "toMenu", sender: nil)
        } else if let errorMessage = error {
            showErrorAlert(message: errorMessage)
        }
    }
    
    func isNetworkRelatedError(_ error: Error) -> Bool {
        let nsError = error as NSError
        let networkErrorDomains = ["NSURLErrorDomain", "com.google.HTTPStatus"]
        let networkErrorCodes = [-1001, -1003, -1004, -1005, -1009]
        
        return networkErrorDomains.contains(nsError.domain) ||
               networkErrorCodes.contains(nsError.code) ||
               nsError.localizedDescription.lowercased().contains("network") ||
               nsError.localizedDescription.lowercased().contains("connection")
    }
    
    func hideLoadingIndicator() {
        if let loadingIndicator = view.viewWithTag(999) {
            loadingIndicator.removeFromSuperview()
        }
    }
    
    func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Sign-In Issue", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - Helper to get the top view controller
    func getTopViewController() -> UIViewController? {
        guard let window = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first?.windows
                .first(where: { $0.isKeyWindow }) else {
            return nil
        }
        
        var topController = window.rootViewController
        while let presentedViewController = topController?.presentedViewController {
            topController = presentedViewController
        }
        return topController
    }
}

