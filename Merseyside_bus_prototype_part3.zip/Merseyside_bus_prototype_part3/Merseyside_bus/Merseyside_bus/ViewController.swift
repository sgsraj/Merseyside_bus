//
//  ViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController {
    
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var accountLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBAction func continueButton(_ sender: Any) {
        performSegue(withIdentifier: "toMenu", sender: nil)
    }
    @IBOutlet weak var continueButton: UIButton!
    
    @IBAction func googleButton(_ sender: Any) {
        guard let rootViewController = UIApplication.shared.windows.first?.rootViewController else {
                print("Error: Unable to get root view controller")
                return
            }

            GIDSignIn.sharedInstance.signIn(withPresenting: rootViewController) { signInResult, error in
                if let error = error {
                    print("Google Sign-In failed: \(error.localizedDescription)")
                    return
                }

                if let user = signInResult?.user {
                    print("User signed in with email: \(user.profile?.email ?? "No email")")
                }
            }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

