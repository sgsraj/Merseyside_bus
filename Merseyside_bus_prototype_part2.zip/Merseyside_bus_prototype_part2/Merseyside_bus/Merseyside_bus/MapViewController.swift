//
//  MapViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 12/04/2025.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate,MKMapViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return routes.count // One row for each route
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let route = routes[indexPath.row]

        let attributedText = NSMutableAttributedString()

        let isExpanded = expandedIndexSet.contains(indexPath.row)
        let expandIcon = isExpanded ? "➖" : "➕"

        let routeTitleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 18)
        ]
        let title = NSAttributedString(string: "\(expandIcon) \(route.name)\n", attributes: routeTitleAttributes)
        attributedText.append(title)

        if isExpanded {
            let stopAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 16)
            ]
            for stop in route.stops {
                let stopLine = NSAttributedString(string: "   • \(stop.stop_name)\n", attributes: stopAttributes)
                attributedText.append(stopLine)
            }
        }

        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.attributedText = attributedText

        // Highlight if it's the matched route
        if highlightedRouteIndex == indexPath.row {
            cell.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.3)
        } else {
            cell.backgroundColor = UIColor.clear
        }

        return cell
    }


    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        if expandedIndexSet.contains(indexPath.row) {
            expandedIndexSet.remove(indexPath.row) // Collapse
        } else {
            expandedIndexSet.insert(indexPath.row) // Expand
        }

        tableView.reloadRows(at: [indexPath], with: .automatic) // Animate change
    }

    func findBestRoute() {
        guard let startText = startTF.text?.lowercased(),
              let endText = endTF.text?.lowercased(),
              !startText.isEmpty,
              !endText.isEmpty else {
            print("Start or End text field is empty.")
            return
        }
        
        highlightedRouteIndex = nil // reset previous highlight

        for (index, route) in routes.enumerated() {
            let stopNames = route.stops.map { $0.stop_name.lowercased() }
            
            if let startIndex = stopNames.firstIndex(where: { $0.contains(startText) }),
               let endIndex = stopNames.firstIndex(where: { $0.contains(endText) }),
               startIndex < endIndex {
                
                // Optional: Further time matching using `timeTF`
                if let userTime = timeTF.text, !userTime.isEmpty {
                    let matchingTimes = route.stops[startIndex].times.filter { $0 >= userTime }
                    if matchingTimes.isEmpty {
                        continue // No time available for the entered time
                    }
                }
                
                // Found the best route!
                highlightedRouteIndex = index
                break
            }
        }
        
        tableView.reloadData()
    }

    
    
    @IBOutlet weak var startTF: UITextField!
    @IBOutlet weak var endTF: UITextField!
    @IBOutlet weak var timeTF: UITextField!
    @IBOutlet weak var myMap: MKMapView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func goButton(_ sender: Any) {
        view.endEditing(true)
        findBestRoute()
    }
    var routes: [(name: String, stops: [BusStop])] = [] // Array of (Route Name, Bus Stops)
    var expandedIndexSet: Set<Int> = [] // To track which rows are expanded
    var highlightedRouteIndex: Int? = nil


    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
                
        loadBusData()
        
        // Do any additional setup after loading the view.
    }
    
    func loadBusData() {
            if let url = Bundle.main.url(forResource: "BusStopsSuper", withExtension: "json") {
                do {
                    let data = try Data(contentsOf: url)
                    let decodedData = try JSONDecoder().decode(SuperBusData.self, from: data)
                    
                    for (routeName, superRoute) in decodedData.routes {
                        routes.append((name: routeName, stops: superRoute.stops))
                    }
                    
                    self.tableView.reloadData()
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            } else {
                print("BusStopsSuper.json file not found")
            }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
